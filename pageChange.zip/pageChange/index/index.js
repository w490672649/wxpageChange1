
Page({

    /**
     * 页面的初始数据
     */
    data: {
        myBase:false,
        myok:true,
        myNum:"1",
        myName:"Wang",
        baseCreate:"2020/01/09 15:20:23",
        myMoney:"100000元",

        mylistNum:"Wu",
        mylistTel:"111111111",
        mylistDate:"2020-02-24",
        mylistmynum:"0",
        mylistState:"确认",

        okInfo:[
            {
                okid:1,
                okState: "待确认",
                okNum:"WangT",
                okContract:"89757",
                okDate:"2020年2月16日",
            },
            {
                okid:2,
                okState: "已确认",
                okNum:"WuX",
                okContract:"89757",
                okDate:"2020年2月15日",
            },
            {
                okid:3,
                okState: "已确认",
                okNum:"DD",
                okContract:"89757",
                okDate:"2020年2月15日",
            },
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    // onChange:function(e){
    //     this.setData({
    //         myBase:!this.data.myBase,
    //         myok:this.data.myBase
    //     })    
    // },
    onInfoChange(){
        this.setData({
            myBase:false,
            myok:true
        })
    },
    onHwChange(){
        this.setData({
            myBase:true,
            myok:false
        })
    },
    onConfirm:function(){
        wx.navigateTo({
            url: '../../index',
        });
    }
})